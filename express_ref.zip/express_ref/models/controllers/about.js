module.exports={
    about: (req,res)=>{
        res.render('about',{title:'За приложението'})
    }
}